/*
* Modou Bamba Biteye, COSC 4381, Instructor Android App Project
* */
package com.example.mob.courseapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;




public class Courses extends AppCompatActivity  {

public static final String Course_NAme = "coursename";
    //Declare the views used in our layout using their id
    EditText edtCourse;
    Button btnAdd;
    ListView lstCourses;
    TextView txtLabel;
    ArrayAdapter<String> ad; //Array adapter for our course list
    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance(); //Firebase auth to obtain user information
    FirebaseUser user = firebaseAuth.getCurrentUser();
    String uId = user.getUid();
    DatabaseReference databaseCourses; // Database reference to store our course information
    Course cs;
    List<String> courseList; //Arraylist to store our courses



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);

        //Initialize the views used in my application
        lstCourses = (ListView) findViewById(R.id.lstCourses);
        edtCourse = (EditText) findViewById(R.id.edtCourse);
        btnAdd = (Button) findViewById(R.id.btnAdd);
        txtLabel = (TextView) findViewById(R.id.txtLabel);
        //Initializing the arraylist so store my course list
        courseList = new ArrayList<>();

        //Setting the user id as the child for our course database
        databaseCourses = FirebaseDatabase.getInstance().getReference(uId);

        txtLabel.setText("My Courses");
        //Listener for adding a new course
        btnAdd.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                addCourse();
        }
        });

        /*
        * Listener used to update our arraylist when the user adds a new course,
        * and display the course in the listview
        * */
        databaseCourses.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                courseList.clear();

                for (DataSnapshot ls : dataSnapshot.getChildren() ){
                    cs = ls.getValue(Course.class);
                    courseList.add(cs.courseName);

                }

                ad = new ArrayAdapter<>(Courses.this,android.R.layout.simple_list_item_1,  courseList);


                lstCourses.setAdapter(ad);



            }



            @Override
            public void onCancelled(DatabaseError databaseError) {
                //
            }
        });

        //attaching listener to listview
        lstCourses.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                //Get the selected course from listview
                String course = courseList.get(i);

                //creating an intent
                Intent intent = new Intent(getApplicationContext(), Selected.class);

                //putting artist name and id to intent

                intent.putExtra(Course_NAme, course);

                //starting the activity with intent
                startActivity(intent);
            }
        });

    }
    private void addCourse() {

        String name = edtCourse.getText().toString().trim();//get the name of new course
        if (!TextUtils.isEmpty(name)) {
            String id = databaseCourses.push().getKey(); //add course to database

            Course course = new Course(id, name);
            databaseCourses.child(id).setValue(course); //add the course as child

        } else {
            Toast.makeText(this, "Please enter a course ", Toast.LENGTH_LONG).show();
        }

    }


}

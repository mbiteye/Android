/*
* Modou Bamba Biteye, COSC 4381, Instructor Android App Project
* */
package com.example.mob.courseapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.text.DateFormat;
import java.util.Date;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {

    private FirebaseAuth firebaseAuth; //Declare firebase authentication object

    //Declare our views used with their if
    private TextView txtUserEmail, txtDateTime;
    private Button btnLogout;
    Button btnCourses;
    String dateTime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        //initialize the firebase object
        firebaseAuth = FirebaseAuth.getInstance();

        //check if the user is logged in
        if(firebaseAuth.getCurrentUser() == null){
            finish();

            startActivity(new Intent(this, LoginActivity.class));
        }

        //getting current user
        FirebaseUser user = firebaseAuth.getCurrentUser();

        //get the current date and time
        dateTime =  DateFormat.getDateTimeInstance().format(new Date());

        //initialize the views
        txtUserEmail = (TextView) findViewById(R.id.txtUserEmail);
        btnLogout = (Button) findViewById(R.id.btnLogout);
        btnCourses = (Button) findViewById(R.id.btnCourses);
        txtDateTime = (TextView) findViewById(R.id.txtDateTime);


        //get the current date and time
        dateTime =  DateFormat.getDateTimeInstance().format(new Date());

        //displaying logged in user name
        txtUserEmail.setText("Welcome " + user.getEmail());

        //Display the current date and time
        txtDateTime.setText(dateTime);

        //adding listener to button
        btnLogout.setOnClickListener(this);
        btnCourses.setOnClickListener(this);
    }


        @Override
        public void onClick(View view) {
            /*
            * If statememnt to determine which button was selected
            * Exit when logout is clicked,
            * navigate to courses class if course button is clicked
            * */
            if(view == btnLogout){
                firebaseAuth.signOut();

                finish();
                startActivity(new Intent(this, LoginActivity.class));
            } else if(view == btnCourses){
                startActivity(new Intent(this, Courses.class));
            }
        }
    }



/*
* Modou Bamba Biteye, COSC 4381, Instructor Android App Project
* */
package com.example.mob.courseapp;

import android.content.Intent;
import android.support.annotation.NonNull;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
//import android.support.v7.appcompat.R;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    public static final String COURSE_NAME = "com.example.mob.courseapp.coursename";

    //declare the objects used in the view
    private EditText edtEmail;
    private EditText edtPassword;
    private Button btnRegister;
    private TextView txtLogin;



    //define the firebaseauth object
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize the created firebaseAuth object
        firebaseAuth = FirebaseAuth.getInstance();


        //check if user already has an account and link them to the profile class
        if(firebaseAuth.getCurrentUser() != null){

            finish();


            startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
        }

        //Initialize the views
        edtEmail = (EditText) findViewById(R.id.edtEmail);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        txtLogin = (TextView) findViewById(R.id.txtLogin);
        btnRegister = (Button) findViewById(R.id.btnRegister);

        //Set the listener for button and textview
        btnRegister.setOnClickListener(this);
        txtLogin.setOnClickListener(this);

    }


    private void register(){

        //obtain email and password from the edit texts
        String email = edtEmail.getText().toString().trim();
        String password  = edtPassword.getText().toString().trim();


        //create a new user
        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        //test if it was successfull
                        if(task.isSuccessful()){
                            finish();
                            startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
                        }else{

                            Toast.makeText(MainActivity.this,"Error Registering User",Toast.LENGTH_LONG).show();
                        }

                    }
                });

    }

    @Override
    public void onClick(View view) {
        //Register the new user when they tap the button
        if(view == btnRegister){
            register();
        }

        //Link the user to the sign in activity if they already have an account
        if(view == txtLogin){
            startActivity(new Intent(this, LoginActivity.class));
        }
    }
}

package com.example.mob.currencyconverter;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;


public class ToUSD extends AppCompatActivity {

    Button btnConvert, btnClear;
    EditText edtAmount;
    TextView txtAmount;
    Spinner spinner;
    ArrayAdapter<CharSequence> adapter;
    String selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_usd);

        btnConvert = (Button) findViewById(R.id.btnConvert);
        txtAmount = (TextView) findViewById(R.id.txtAmount);
        edtAmount = (EditText) findViewById(R.id.edtAmount);
        btnClear = (Button) findViewById(R.id.btnClear);
        spinner = (Spinner) findViewById(R.id.spinner);

        //Create and set adapter for the spinner
        adapter = ArrayAdapter.createFromResource(this, R.array.country_names, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);



        //set on item selected listener
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selected = spinner.getItemAtPosition(i).toString();
                //txtAmount.setText(selected);

                btnConvert.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //obtain the amount entered by the user
                        double num = Double.parseDouble(edtAmount.getText().toString());

                        //The rates obtained are to be used to convert amounts
                        double xof = 558.0;
                        double gmd = 47.45;
                        double cny = 6.65;
                        double cad = 1.28;
                        double gbp = 0.76;
                        double eur = .85;
                        double ngn = 360.50;

 /*
                        The following if statements are used to determine which currency to convert from.
                        Setting the amount displayed based on the selected currency and round up.
                         */

                        if (selected.equals("Senegal(XOF)")) {

                            num = Math.round((num / xof)*100.0)/100.0;

                        } else  if (selected.equals("Gambia(GMD)")) {
                            num =  Math.round((num / gmd)*100.0)/100.0;


                        } else  if (selected.equals("China(CNY)")) {
                            num = Math.round((num / cny)*100.0)/100.0;

                        }else  if (selected.equals("Canada(CAD)")) {
                            num = Math.round((num / cad)*100.0)/100.0;

                        }else  if (selected.equals("Britain(GBP)")) {
                            num = Math.round((num / gbp)*100.0)/100.0;

                        }else  if (selected.equals("Euro(EUR)")) {
                            num = Math.round((num / eur)*100.0)/100.0;

                        }else  if (selected.equals("Nigeria(NGN)")) {
                            num = Math.round((num / ngn)*100.0)/100.0;


                        }

                        txtAmount.setText("The amount in USD is: " + Double.toString(num));
                    }
                });

                //Button listener  to clear the amount in the textbox
                btnClear.setOnClickListener(new View.OnClickListener(){

                    @Override
                    public void onClick(View view) {
                        edtAmount.setText("");
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Toast.makeText(getApplicationContext(), "Please select a country!", Toast.LENGTH_LONG).show();
            }



        });

    }
}

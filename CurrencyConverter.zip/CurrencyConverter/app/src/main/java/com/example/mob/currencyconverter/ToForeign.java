package com.example.mob.currencyconverter;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;


public class ToForeign extends AppCompatActivity {

    Button btnConvert, btnClear;
    EditText edtAmount;
    TextView txtAmount;
    Spinner spinner;
    ArrayAdapter<CharSequence> adapter;
    String selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_to_foreign);

        //Initialize the views used
        btnConvert = (Button) findViewById(R.id.btnConvert);
        txtAmount = (TextView) findViewById(R.id.txtAmount);
        edtAmount = (EditText) findViewById(R.id.edtAmount);
        btnClear = (Button) findViewById(R.id.btnClear);
        spinner = (Spinner) findViewById(R.id.spinner);

        //Create and set adapter for the spinner
        adapter = ArrayAdapter.createFromResource(this, R.array.country_names, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);



        //set on item selected listener
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                selected = spinner.getItemAtPosition(i).toString();
                //txtAmount.setText(selected);

                btnConvert.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        //Obtain the amount entered by the user
                        double num = Double.parseDouble(edtAmount.getText().toString());

                        //Converting the amount entered by user with the selected rate
                        double xof = num * 558.0;
                        double gmd = num * 47.45;
                        double cny = num*  6.65;
                        double cad = num * 1.28;
                        double gbp = num * 0.76;
                        double eur = num * .85;
                        double ngn = num * 360.50;


                        /*
                        The following if statements are used to determine which currency to convert to.
                        Setting the amount displayed based on the selected currency and round up.
                         */
                        if (selected.equals("Senegal(XOF)")) {

                            num = Math.round((xof)*100.0)/100.0;
                              txtAmount.setText("The amount in XOF is: " + Double.toString(num));
                        } else  if (selected.equals("Gambia(GMD)")) {
                            num = Math.round((gmd)*100.0)/100.0;
                             txtAmount.setText("The amount in GMD is: " + Double.toString(num));

                        } else  if (selected.equals("China(CNY)")) {
                            num = Math.round((cny)*100.0)/100.0;
                            txtAmount.setText("The amount in CNY is: " + Double.toString(num));

                        }else  if (selected.equals("Canada(CAD)")) {
                            num = Math.round((cad)*100.0)/100.0;
                            txtAmount.setText("The amount in CAD is: " + Double.toString(num));

                        }else  if (selected.equals("Britain(GBP)")) {
                            num = Math.round((gbp)*100.0)/100.0;
                             txtAmount.setText("The amount in GBP is: " + Double.toString(num));

                        }else  if (selected.equals("Euro(EUR)")) {
                            num = Math.round(( eur)*100.0)/100.0;
                            txtAmount.setText("The amount in EUR is: " + Double.toString(num));

                        }else  if (selected.equals("Nigeria(NGN)")) {
                            num = Math.round((ngn)*100.0)/100.0;

                            txtAmount.setText("The amount in NGN is: " + Double.toString(num));
                        }

                        //txtAmount.setText("The converted amount is: " + Double.toString(num));
                    }


                });

                //Button listener  to clear the amount in the textbox
                btnClear.setOnClickListener(new View.OnClickListener(){

                    @Override
                    public void onClick(View view) {
                        edtAmount.setText("");
                    }
                });
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Toast.makeText(getApplicationContext(), "Please select a country!", Toast.LENGTH_LONG).show();
            }



        });

    }
}

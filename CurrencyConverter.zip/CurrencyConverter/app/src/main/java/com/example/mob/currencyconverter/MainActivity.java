/*
Modou Bamba Biteye, COSC 4381, Students Android App
 */

package com.example.mob.currencyconverter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView lstRates;
    Button btnToUSD, btnToForeign;
    //String to store our concersion rates
    String[] rates = {"CFA: 558.0", "GMD: 47.45", "CNY: 6.65", "CAD: 1.28 ","GBP: 0.76 ", "EUR: 0.85","NGN: 360.50 " };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       //set adapter for our string array
        ListAdapter ad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,rates);

        //reference to my listview
        lstRates  = (ListView) findViewById(R.id.lstRates);
        btnToUSD  = (Button) findViewById(R.id.btnToUs);
        btnToForeign  = (Button) findViewById(R.id.btnToForeign);


        //set adapter to list view
        lstRates.setAdapter(ad);

        //Set the listener for first button
        btnToUSD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent In = new Intent(MainActivity.this, ToUSD.class);
                MainActivity.this.startActivity(In);
            }
        });

        btnToForeign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent In = new Intent(MainActivity.this, ToForeign.class);
                MainActivity.this.startActivity(In);
            }
        });
    }
}

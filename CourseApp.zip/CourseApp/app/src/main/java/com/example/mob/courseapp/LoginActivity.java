package com.example.mob.courseapp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    private FirebaseAuth firebaseAuth;

    private EditText edtEmail;
    private EditText edtPassword;
    private TextView txtRegister;
    private Button btnLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //initialize the firebaseauth object
        firebaseAuth = FirebaseAuth.getInstance();

        //check if the user is logged in
        if(firebaseAuth.getCurrentUser() != null){
            finish();
            //if user is logged in, open profile activity
            startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
        }

        //inintialize the views in this activity
        edtEmail = (EditText) findViewById(R.id.edtEmail);
        edtPassword = (EditText) findViewById(R.id.edtPassword);
        btnLogin = (Button) findViewById(R.id.btnLogin);
        txtRegister  = (TextView) findViewById(R.id.txtRegister);


        //set the onclick listers
        btnLogin.setOnClickListener(this);
        txtRegister.setOnClickListener(this);
    }

    //method for user login
    private void userLogin() {
        String email = edtEmail.getText().toString().trim();
        String password = edtPassword.getText().toString().trim();


        firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if(task.isSuccessful()){

                            finish();
                            startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
                        }
                    }
                });
    }

    @Override
    public void onClick(View view) {
        if(view == btnLogin){
            userLogin();
        }

        if(view == txtRegister){
            finish();
            startActivity(new Intent(this, MainActivity.class));
        }
    }
}


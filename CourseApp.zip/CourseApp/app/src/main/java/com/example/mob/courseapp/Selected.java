/*
* Modou Bamba Biteye, COSC 4381, Instructor Android App Project
* */

package com.example.mob.courseapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;


public class Selected extends AppCompatActivity {

//Declare the views in the layout using their id
    TextView txtCourse;
    Button btnSelect, btnHome;
    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance(); //Firebase auth to get user information
    FirebaseUser user = firebaseAuth.getCurrentUser();
    String name = user.getEmail();
    StorageReference store; //Storage reference for uploading files to our database
    String courseName;




    private static final int IMAGE_PICK = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected);

        //Initialize the views in my layout
        txtCourse = (TextView) findViewById(R.id.txtCourse);
        btnSelect = (Button) findViewById(R.id.btnSelect);
        btnHome = (Button) findViewById(R.id.btnHome);

//Initialize the firebase storage reference
        store = FirebaseStorage.getInstance().getReference(name);


        //Intent needed for obtaining current course
        Intent intent = getIntent();

        //Obtain the course name that was selected
         courseName = intent.getStringExtra(Courses.Course_NAme);
        txtCourse.setText("Welcome to " + courseName);


        //Onclick listener for uploading a new image
        btnSelect.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                //For choosing a file
                Intent I = new Intent(Intent.ACTION_PICK);
                //Set the file type to image
                I.setType("image/*");

                startActivityForResult(I, IMAGE_PICK);


            }
        });

        //Onclick listener for when the user clicks the home button
        btnHome.setOnClickListener(new View.OnClickListener(){


            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), ProfileActivity.class));
            }
        } );
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //Check if the request code matches our static variable and the result is ok
        if(requestCode == IMAGE_PICK && resultCode == RESULT_OK){


            Uri uri = data.getData(); //used to obtain the data

            //Create another storage reference and set selected courename as child
            StorageReference filepath = store.child(courseName).child(uri.getLastPathSegment());

            //Display a message if the file was successfully uploaded to firebase storage
            filepath.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Toast.makeText(Selected.this, "Successfully Uploaded!", Toast.LENGTH_LONG).show();
                }
            });

        }
    }
}

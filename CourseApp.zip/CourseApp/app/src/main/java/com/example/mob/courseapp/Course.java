package com.example.mob.courseapp;

/**
 * Modou Bamba Biteye, INstructor Android App Project
 * This class will  be used to create a new course with a name and id
 * This will be stored in the firebase database using the id as the node identifier
 */

public class Course {
    String courseId, courseName; // Declare the variables used


    public Course(){

    }


    public Course(String courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
    }

    //Obtain the entered course id and return it
    public String getCourseId() {

        return courseId;
    }
    //Obtain the entered course name and return it
    public  String getCourseName() {

        return courseName;
    }


}
